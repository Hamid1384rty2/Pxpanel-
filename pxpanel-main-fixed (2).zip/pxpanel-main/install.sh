#!/usr/bin/env bash
# PXPanel one-shot installer for a Linux server (Ubuntu/Debian).
# Usage: sudo bash install.sh
# Optional: ADMIN_PASSWORD=... PORT=8880 sudo -E bash install.sh
set -e

APP_DIR="/opt/pxpanel"
DATA_DIR="/var/lib/pxpanel"
PORT="${PORT:-8880}"
NO_DOMAIN_PORT="${NO_DOMAIN_PORT:-8880}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run as root: sudo bash install.sh"
  exit 1
fi

echo ">> Installing system packages..."
apt-get update -y
apt-get install -y python3 python3-venv python3-pip curl

echo ">> Copying files to $APP_DIR ..."
mkdir -p "$APP_DIR" "$DATA_DIR"
cp -r "$SRC_DIR"/. "$APP_DIR"/

echo ">> Installing Python dependencies..."
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"

ENV_LINES="Environment=PORT=$PORT
Environment=DATA_DIR=$DATA_DIR
Environment=RAILWAY_VOLUME_MOUNT_PATH=$DATA_DIR
Environment=NO_DOMAIN_PORT=$NO_DOMAIN_PORT"
if [ -n "$ADMIN_PASSWORD" ]; then
  ENV_LINES="$ENV_LINES
Environment=ADMIN_PASSWORD=$ADMIN_PASSWORD"
fi

echo ">> Creating systemd service..."
cat > /etc/systemd/system/pxpanel.service <<UNIT
[Unit]
Description=PXPanel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
$ENV_LINES
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/main.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable pxpanel
systemctl restart pxpanel

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow "$PORT"/tcp || true
  ufw allow "$NO_DOMAIN_PORT"/tcp || true
fi

SERVER_IP="$(curl -s --max-time 5 https://api.ipify.org || true)"
if [ -z "$SERVER_IP" ]; then
  SERVER_IP="$(hostname -I | awk '{print $1}')"
fi

echo ""
echo "========================================================"
echo " PXPanel installed and running."
echo " Open the panel here: http://$SERVER_IP:$PORT"
echo " No-domain config port: $NO_DOMAIN_PORT (open it in your firewall/provider panel)"
echo " Default password: ${ADMIN_PASSWORD:-set it on first login}"
echo "========================================================"
